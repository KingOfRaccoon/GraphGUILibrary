# mxgraph-js

Just the JS portion of [mxGraph](https://github.com/jgraph/mxgraph).
